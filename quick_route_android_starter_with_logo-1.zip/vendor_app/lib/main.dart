import 'package:flutter/material.dart';

void main() => runApp(const QuickRouteApp());

class QuickRouteApp extends StatelessWidget {
  const QuickRouteApp({super.key});

  @override
  Widget build(BuildContext context) {
    const brand = Color(0xFF12A879);
    return MaterialApp(
      title: 'Quick Route Vendor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: brand),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('QUICK ROUTE', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.1)),
        backgroundColor: Colors.white,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: const Color(0xFF10243A),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset('assets/quick_route_logo.png', height: 190, fit: BoxFit.contain),
                  SizedBox(height: 16),
                  Text('VENDOR', style: TextStyle(color: Color(0xFF42D6A0), fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('Manage your restaurant and incoming orders.', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700)),
                  SizedBox(height: 8),
                  Text('Your Food, Our Route.', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text('FEATURES', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
            const SizedBox(height: 10),
            ...[
              _FeatureTile(icon: Icons.check_circle_outline, title: 'Vendor application'),,
              _FeatureTile(icon: Icons.check_circle_outline, title: 'Manage menu and prices'),,
              _FeatureTile(icon: Icons.check_circle_outline, title: 'Accept or reject orders'),,
              _FeatureTile(icon: Icons.check_circle_outline, title: 'Mark orders as preparing and ready'),
            ],
            const SizedBox(height: 18),
            const Text(
              'Starter preview: connect authentication, database, maps and payment gateway before using this app with real customers.',
              style: TextStyle(color: Colors.black54, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.icon, required this.title});
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF12A879)),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
