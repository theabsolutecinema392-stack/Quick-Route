# Quick Route — Android starter project

This is a starter source bundle for four separate Android apps:
- customer_app
- vendor_app
- delivery_app
- admin_app

## Important
This bundle is a UI/source-code starter, not four installable production APKs.
To create APKs, install Flutter and Android Studio, configure Android signing,
connect a backend, then build each app separately.

## Build an app
For each app folder:
1. Run `flutter create .` (inside that folder) if platform folders are not present.
2. Run `flutter pub get`
3. Run `flutter build apk --release`

Repeat for all four app folders.

## Backend architecture
Use one shared backend for all four apps. A suitable first implementation:
- Firebase Authentication: phone/email sign-in and role claims
- Cloud Firestore: users, vendors, menu_items, orders, delivery_assignments, payments
- Cloud Functions: order assignment, status transitions, payment verification
- Firebase Cloud Messaging: new order and delivery notifications
- Maps provider: pickup/drop-off map and route display

Do not trust payment success reported by the mobile app. Verify gateway signatures
on a trusted server endpoint before marking an order paid.

## Payment methods
- UPI and debit/credit cards: integrate a supported payment gateway (for example,
  Razorpay) after creating a merchant account and completing its approval/KYC.
- Cash on Delivery: record as `payment_method: cod` and reconcile cash collection.
- Never put secret API keys in an Android app. Store secrets only on the backend.

## Suggested order lifecycle
`placed -> vendor_accepted -> preparing -> ready_for_pickup -> picked_up -> delivered`
Alternative terminal states: `vendor_rejected`, `cancelled`, `delivery_failed`.

## Before real launch
Add privacy policy, terms, support contacts, refund/cancellation rules, tax and
business details, secure role-based access rules, location permissions disclosure,
and production monitoring. Test payments and order flows in sandbox first.

## Branding update
The new static black, gold, red and white Quick Route logo is included in all four apps at `assets/quick_route_logo.png` and displayed on their home screens.
