# Shared backend data model (initial specification)

## users
- uid, display_name, phone, email, role (`customer|vendor|delivery|admin`), created_at

## vendors
- vendor_id, owner_uid, business_name, address, location, status (`pending|approved|rejected`), documents, created_at

## menu_items
- item_id, vendor_id, name, description, price_paise, available, image_url

## orders
- order_id, customer_uid, vendor_id, items[], subtotal_paise, delivery_fee_paise,
  total_paise, payment_method (`upi|card|cod`), payment_status,
  order_status, pickup_address, dropoff_address, assigned_partner_uid, timestamps

## delivery_assignments
- assignment_id, order_id, partner_uid, accepted_at, picked_up_at, delivered_at,
  delivery_status, cash_collected_paise

## payments
- payment_id, order_id, gateway, gateway_order_id, gateway_payment_id,
  amount_paise, status, verified_at

## Access rules (must be enforced server-side)
- Customers can read their own orders.
- Vendors can read orders for their own vendor account.
- Delivery partners can read only assignments offered to or assigned to them.
- Admin actions require a verified admin role claim.
- Clients cannot write `payment_status=paid` or assign themselves as admin.
